import javax.swing.*;
import javax.swing.border.EmptyBorder;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Chat extends JDialog {

    private static final long serialVersionUID = 1L;
    private final JPanel contentPanel = new JPanel();
    private JTextField txtEnviar;
    private RoundedButton btnNewButton;
    private String textoTotal = "";
    public String usuario; // Variable para almacenar el nombre de usuario
    private JLabel lblNewLabel_1;
    JTextPane textPane;

    public Chat(String usuario) {
        this.usuario = usuario; // Guardamos el nombre del usuario

        setBounds(100, 100, 493, 687);
        getContentPane().setLayout(new BorderLayout());
        contentPanel.setBorder(new EmptyBorder(5, 5, 5, 5));
        getContentPane().add(contentPanel, BorderLayout.CENTER);
        contentPanel.setLayout(null);

        JLabel lblNewLabel = new JLabel("CHAT");
        lblNewLabel.setFont(new Font("Segoe UI Emoji", Font.BOLD | Font.ITALIC, 30));
        lblNewLabel.setBounds(192, 10, 95, 43);
        contentPanel.add(lblNewLabel);

        txtEnviar = new JTextField();
        txtEnviar.setFont(new Font("Segoe UI Emoji", Font.PLAIN, 20));
        txtEnviar.setBounds(23, 540, 292, 57);
        contentPanel.add(txtEnviar);
        txtEnviar.setColumns(10);

        JScrollPane scrollPane = new JScrollPane();
        scrollPane.setHorizontalScrollBarPolicy(ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
        scrollPane.setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS);
        scrollPane.setBounds(31, 63, 416, 443);
        contentPanel.add(scrollPane);
        
        textPane = new JTextPane();
        textPane.setFont(new Font("Segoe UI Emoji", Font.PLAIN, 20));
        scrollPane.setViewportView(textPane);

        btnNewButton = new RoundedButton("ENVIAR");
        btnNewButton.setBorderPainted(false);
        btnNewButton.setBackground(new Color(159, 255, 159));
        btnNewButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String texto = txtEnviar.getText();
                textoTotal += "Tú: " + texto;
                textPane.setText(textoTotal);
                txtEnviar.setText("");
            }
        });

        btnNewButton.setFont(new Font("Segoe UI Emoji", Font.PLAIN, 20));
        btnNewButton.setBounds(325, 583, 122, 57);
        contentPanel.add(btnNewButton);

        lblNewLabel_1 = new JLabel("");
        lblNewLabel_1.setIcon(new ImageIcon("C:\\Users\\haima\\Desktop\\eclipse-workspace\\eclipse-workspace\\Reto\\src"));
        lblNewLabel_1.setBounds(325, 10, 114, 98);
        contentPanel.add(lblNewLabel_1);

        // Botón para abrir el menú de emojis
        RoundedButton btnEmoji = new RoundedButton("😊");
        btnEmoji.setFont(new Font("Segoe UI Emoji", Font.PLAIN, 20));
        btnEmoji.setBounds(325, 516, 122, 57);
        btnEmoji.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                // Crear el ComboBox con emojis
                String[] emojis = {"🤣", "👌", "🤑", "👍", "🔥", "❤️","😭","💀"};
                JComboBox<String> emojiSelector = new JComboBox<>(emojis);
                emojiSelector.setFont(new Font("Segoe UI Emoji", Font.PLAIN, 20));

                // Mostrar el selector de emojis en un JOptionPane
                int result = JOptionPane.showConfirmDialog(
                        contentPanel,
                        emojiSelector,
                        "Selecciona un emoji",
                        JOptionPane.OK_CANCEL_OPTION,
                        JOptionPane.PLAIN_MESSAGE
                );

                // Si el usuario selecciona un emoji, agregarlo al campo de texto
                if (result == JOptionPane.OK_OPTION) {
                    String selectedEmoji = (String) emojiSelector.getSelectedItem();
                    txtEnviar.setText(txtEnviar.getText() + selectedEmoji);
                }
            }
        });
        contentPanel.add(btnEmoji);
    }

    public void recibirMensaje(String mensaje) {
        SwingUtilities.invokeLater(() -> {
            textoTotal += mensaje + "\n";
            textPane.setText(textoTotal);
        });
    }

    public JTextField getTxtEnviar() {
        return txtEnviar;
    }

    public JButton getBtnEnviar() {
        return btnNewButton;
    }
}
