import javax.swing.*;
import javax.swing.border.EmptyBorder;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Chat extends JDialog {

    private static final long serialVersionUID = 1L;
    private final JPanel contentPanel = new JPanel();
    private JTextField txtEnviar;
    private RoundedButton btnNewButton;
    private String textoTotal = "";
    public String usuario; // Variable para almacenar el nombre de usuario
    private JLabel lblNewLabel_1;
    JTextPane textPane;

    public Chat(String usuario) {
        this.usuario = usuario; // Guardamos el nombre del usuario

        setBounds(100, 100, 516, 756);
        getContentPane().setLayout(new BorderLayout());
        contentPanel.setBorder(new EmptyBorder(5, 5, 5, 5));
        getContentPane().add(contentPanel, BorderLayout.CENTER);
        contentPanel.setLayout(null);

        JLabel lblNewLabel = new JLabel("CHAT");
        lblNewLabel.setFont(new Font("Segoe UI Emoji", Font.BOLD | Font.ITALIC, 30));
        lblNewLabel.setBounds(192, 10, 95, 43);
        contentPanel.add(lblNewLabel);

        txtEnviar = new JTextField();
        txtEnviar.setFont(new Font("Segoe UI Emoji", Font.PLAIN, 20));
        txtEnviar.setBounds(76, 624, 292, 57);
        contentPanel.add(txtEnviar);
        txtEnviar.setColumns(10);

        JScrollPane scrollPane = new JScrollPane();
        scrollPane.setHorizontalScrollBarPolicy(ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
        scrollPane.setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS);
        scrollPane.setBounds(37, 63, 418, 551);
        contentPanel.add(scrollPane);
        
        textPane = new JTextPane();
        textPane.setFont(new Font("Segoe UI Emoji", Font.PLAIN, 20));
        scrollPane.setViewportView(textPane);
        textPane.setContentType("text/html");

        btnNewButton = new RoundedButton("ENVIAR");
        btnNewButton.setBorderPainted(false);
        btnNewButton.setBackground(new Color(159, 255, 159));
	        btnNewButton.addActionListener(new ActionListener() {
	            public void actionPerformed(ActionEvent e) {
	                txtEnviar.setText("");
	            }
	        });

        btnNewButton.setFont(new Font("Segoe UI Emoji", Font.PLAIN, 20));
        btnNewButton.setBounds(378, 624, 114, 57);
        contentPanel.add(btnNewButton);

        lblNewLabel_1 = new JLabel("");
        lblNewLabel_1.setIcon(new ImageIcon("C:\\Users\\haima\\Desktop\\eclipse-workspace\\eclipse-workspace\\Reto\\src"));
        lblNewLabel_1.setBounds(325, 10, 114, 98);
        contentPanel.add(lblNewLabel_1);

        // Botón para abrir el menú de emojis
        RoundedButton btnEmoji = new RoundedButton("😊");
        btnEmoji.setFont(new Font("Segoe UI Emoji", Font.PLAIN, 15));
        btnEmoji.setBounds(3, 625, 63, 57);
        btnEmoji.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                // Crear el ComboBox con emojis
                String[] emojis = {"🤣", "👌", "🤑", "👍", "🔥", "❤️","😭","💀"};
                JComboBox<String> emojiSelector = new JComboBox<>(emojis);
                emojiSelector.setFont(new Font("Segoe UI Emoji", Font.PLAIN, 20));

                // Mostrar el selector de emojis en un JOptionPane
                int result = JOptionPane.showConfirmDialog(
                        contentPanel,
                        emojiSelector,
                        "Selecciona un emoji",
                        JOptionPane.OK_CANCEL_OPTION,
                        JOptionPane.PLAIN_MESSAGE
                );

                // Si el usuario selecciona un emoji, agregarlo al campo de texto
                if (result == JOptionPane.OK_OPTION) {
                    String selectedEmoji = (String) emojiSelector.getSelectedItem();
                    txtEnviar.setText(txtEnviar.getText() + selectedEmoji);
                }
            }
        });
        contentPanel.add(btnEmoji);
    }

    public void recibirMensaje(String mensaje) {
        SwingUtilities.invokeLater(() -> {
            // Verificar si el mensaje es un mensaje especial de entrada o salida
            if (mensaje.contains("ha ingresado al chat") || mensaje.contains("ha salido del chat")) {
                // Si es un mensaje de ingreso/salida, alineamos al centro y no mostramos el emisor
                textoTotal += "<p style='text-align: center; margin-bottom: 10px;'>" + mensaje + "</p>";
            } else {
                // Si es un mensaje normal, lo procesamos como antes
                String[] partes = mensaje.split(":");
                String emisor = partes[0];
                String textoMensaje = partes[1];

                if (emisor.equals(usuario)) {
                    // Si el mensaje proviene del propio usuario, se alinea a la derecha
                    textoTotal += "<p style='text-align: right; display: inline-block; padding: 10px;"
                            + "color: #0041db;'>Tú: " + textoMensaje + "</p>";
                } else {
                    // Si no, se alinea a la izquierda por defecto
                    textoTotal += "<p style='text-align: left; display: inline-block; padding: 10px; "
                            + "color:  #a10000;'>" + emisor + ": " + textoMensaje + "</p>";
                }
            }

            textPane.setText("<html><body style='margin: 0; padding: 0;'>" + textoTotal + "</body></html>");
        });
    }
    private String escapeHtml(String text) {
        return text.replace("&", "&amp;")
                   .replace("<", "&lt;")
                   .replace(">", "&gt;")
                   .replace("\"", "&quot;")
                   .replace("'", "&#39;");
    }

    public JTextField getTxtEnviar() {
        return txtEnviar;
    }

    public JButton getBtnEnviar() {
        return btnNewButton;
    }
}
