
import com.cloudinary.*;
import com.cloudinary.utils.ObjectUtils;
import io.github.cdimascio.dotenv.Dotenv;

import java.io.File;
import java.io.IOException;
import java.util.Map;


public class URLTest {

	public static void main(String[] args) {
		Dotenv dotenv = Dotenv.load();
		Cloudinary cloudinary = new Cloudinary(dotenv.get("CLOUDINARY_URL"));
		System.out.println(cloudinary.config.cloudName);
		
		// Upload the image
		Map params1 = ObjectUtils.asMap(
		    "use_filename", true,
		    "unique_filename", false,
		    "overwrite", true
		);


		try {
			String filePath = "C:/Users/golde/Desktop/hello.jpg";
			File file = new File(filePath);



			System.out.println(
			        cloudinary.uploader().upload(filePath, params1));
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
